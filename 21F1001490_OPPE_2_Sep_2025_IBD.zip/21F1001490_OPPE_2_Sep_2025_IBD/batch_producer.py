# batch_producer.py
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_timestamp, lit, coalesce, last, expr, struct
from pyspark.sql import Window
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType

# Passing the Kafka IP and GCS Bucket name as arguments to the job
KAFKA_TOPIC = "air_quality_stream"

def start_spark_session():
    """Initializes and returns the Spark Session."""
    spark = SparkSession.builder.appName("AQIBatchProducer").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    # Setting the timezone to UTC for consistent windowing, matching the timestamp format
    spark.conf.set("spark.sql.session.timeZone", "UTC")
    return spark

def define_schema():
    """Defines the schema based on the Kaggle description."""
    # Only including columns we need for processing (City, Timestamp, Pollutants, AQI)
    return StructType([
        StructField("timestamp", StringType(), True),
        StructField("country", StringType(), True),
        StructField("city", StringType(), True),
        StructField("latitude", DoubleType(), True),
        StructField("longitude", DoubleType(), True),
        StructField("pm25", DoubleType(), True),
        StructField("pm10", DoubleType(), True),
        StructField("no2", DoubleType(), True),
        StructField("so2", DoubleType(), True),
        StructField("o3", DoubleType(), True),
        StructField("co", DoubleType(), True), 
        StructField("aqi", IntegerType(), True),
        StructField("temperature", DoubleType(), True),
        StructField("humidity", DoubleType(), True),
        StructField("wind_speed", DoubleType(), True)
    ])

def clean_and_impute(spark, input_path, raw_schema):
    """Handles data quality issues."""
    
    raw_df = spark.read.csv(
        input_path, 
        header=True, 
        schema=raw_schema, 
        mode="PERMISSIVE"
    )

    #  Convert timestamp and filter bad rows (where timestamp or AQI is null)
    # Filter: bad row handling (assuming non-null timestamp/AQI is required)
    # Also, cast pollutants to Double and CO to µg/m³ (conversion factor 1 mg/m3 = 1000 µg/m3)
    clean_df = raw_df.withColumn("processed_time", to_timestamp(col("timestamp"), "yyyy-MM-dd HH:mm:ss.SSSSSS")) \
                     .filter(col("processed_time").isNotNull() & col("aqi").isNotNull()) \
                     .withColumn("co_ugm3", col("co") * 1000.0) # Convert mg/m3 to ug/m3 for consistency
    
    # Handle Missing Hours (The Complex Imputation Step)
    
    # Order the data by city and time (Required because input is unsorted)
    window_spec = Window.partitionBy("city").orderBy("processed_time")

    # Impute missing values (fill forward) for all critical columns
    # We use the 'last' function with ignoreNulls=True to carry forward the previous non-null value
    imputed_df = clean_df.withColumn(
        "pm25", coalesce(col("pm25"), last("pm25", True).over(window_spec))
    ).withColumn(
        "pm10", coalesce(col("pm10"), last("pm10", True).over(window_spec))
    ).withColumn(
        "no2", coalesce(col("no2"), last("no2", True).over(window_spec))
    ).withColumn(
        "so2", coalesce(col("so2"), last("so2", True).over(window_spec))
    ).withColumn(
        "o3", coalesce(col("o3"), last("o3", True).over(window_spec))
    ).withColumn(
        "co_ugm3", coalesce(col("co_ugm3"), last("co_ugm3", True).over(window_spec))
    ).withColumn(
        "aqi", coalesce(col("aqi"), last("aqi", True).over(window_spec))
    ).select(
        "processed_time",
        "city",
        "aqi",
        "pm25",
        "pm10",
        "no2",
        "so2",
        "o3",
        "co_ugm3"
    ).withColumnRenamed("processed_time", "timestamp_utc")

    # Final filter: remove rows that still have nulls after imputation (i.e., the first row for a city)
    return imputed_df.filter(col("aqi").isNotNull())

def produce_to_kafka(df, kafka_brokers):
    """Sends the cleaned DataFrame to Kafka."""
    
    # The message value must be a string (usually JSON)
    kafka_df = df.select(
        col("city").cast("string").alias("key"), # Use city as key for partitioning
        expr("to_json(struct(*))").alias("value") # Convert entire data row to JSON string
    )

    print(f"Writing data to Kafka topic: {KAFKA_TOPIC} at {kafka_brokers}...")
    
    # Write the batch as a stream of messages to Kafka
    kafka_df.write \
        .format("kafka") \
        .option("kafka.bootstrap.servers", kafka_brokers) \
        .option("topic", KAFKA_TOPIC) \
        .save()
        
    print("Batch job complete. Data produced to Kafka.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        # Check that both arguments (GCS Path and Kafka IP) are provided
        print("Usage: batch_producer.py <gcs_input_path> <kafka_vm_internal_ip:9092>")
        sys.exit(-1)

    GCS_INPUT_PATH = sys.argv[1]
    KAFKA_BROKERS = sys.argv[2]
    
    spark = start_spark_session()
    raw_schema = define_schema()
    
    # The imputation logic handles unsorted data and missing values simultaneously.
    # the functional requirements for "fill missing timestamps by carrying forward the previous minute’s price & volume" (or hour's data in this case).
    
    final_df = clean_and_impute(spark, GCS_INPUT_PATH, raw_schema)
    
    # This is a good check for the screencast/submission
    print(f"Final cleaned and imputed records to stream: {final_df.count()}")
    
    produce_to_kafka(final_df, KAFKA_BROKERS)
    
    spark.stop()