# Importing Relevant libraries
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, window, max, sum, rank, desc, asc, expr, struct
from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType, TimestampType
from pyspark.sql import Window

# Configuring the Kafka Topic 
KAFKA_TOPIC = "air_quality_stream"
# Checkpint location for the Air Quality Stream
CHECKPOINT_LOCATION = "gs://ibd-oppe2-varun/checkpoint/air_quality_rank" 

def start_spark_session():
    """Initializing and Returning the Spark Session"""
    spark = SparkSession.builder.appName("AQIStreamingRanker").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.session.timeZone", "UTC")
    return spark

# Defining the Schema as per the Requirement
payload_schema = StructType([
    StructField("timestamp_utc", TimestampType(), True),
    StructField("city", StringType(), True),
    StructField("aqi", IntegerType(), True),
    StructField("pm25", DoubleType(), True),
    StructField("pm10", DoubleType(), True),
    StructField("no2", DoubleType(), True),
    StructField("so2", DoubleType(), True),
    StructField("o3", DoubleType(), True),
    StructField("co_ugm3", DoubleType(), True)
])

def process_batch(current_df, batch_id):
    """
    Function executed by foreachBatch: applies global ranking logic
    to the final aggregated results of the window.
    """
    if current_df.count() == 0:
        return # It will skip the empty batches
        
    # Defining the Ranking Window: Rank across the entire result set
    # Ranking Rule as per problem statement is Lower V1 (Max AQI) is better (ASC). Tie-breaker can be Lower V2 (Sum Pollutants) is better (ASC).
    ranking_window = Window.orderBy(asc(col("V1_Max_AQI")), asc(col("V2_Sum_Pollutants")))

    #Applying the Global Rank
    ranked_df = current_df.withColumn(
        "Rank", rank().over(ranking_window)
    )

    # Formatting the Output
    output_df = ranked_df.select(
        col("window.end").alias("Window_End_Time"), # When the 8-hour window closes
        col("city"),
        col("Rank"),
        col("V1_Max_AQI"),
        col("V2_Sum_Pollutants")
    ).orderBy(col("Window_End_Time"), col("Rank"))

    # Writing to the console
    print(f"--- Batch {batch_id} - Ranks for Completed Windows ---")
    output_df.show(truncate=False)


def run_streaming_job(kafka_brokers):
    """Setting up and running the Structured Streaming job."""
    spark = start_spark_session()
    
    # Read from Kafka
    kafka_stream_df = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", kafka_brokers) \
        .option("subscribe", KAFKA_TOPIC) \
        .option("startingOffsets", "earliest") \
        .load()

    # Deserialize and Prepare Data
    parsed_stream_df = kafka_stream_df \
        .selectExpr("CAST(value AS STRING)") \
        .withColumn("json_data", from_json(col("value"), payload_schema)) \
        .select(col("json_data.*"))
    
    # Define Windowing and Watermark
    watermarked_df = parsed_stream_df.withWatermark("timestamp_utc", "1 hour")
    
    # Defining 8-hour tumbling window grouped by city 
    windowed_df = watermarked_df.groupBy(
        window("timestamp_utc", "8 hours"), 
        "city"
    ).agg(
        # V1: Max AQI in the last 8 hours
        max(col("aqi")).alias("V1_Max_AQI"),
        # V2: Sum total of all pollutant concentrations (PM25, PM10, NO2, SO2, O3, CO_ugm3)
        sum(
            col("pm25") + col("pm10") + col("no2") + col("so2") + col("o3") + col("co_ugm3")
        ).alias("V2_Sum_Pollutants")
    )
    
    # Writing Stream using foreachBatch for Global Ranking
    print("Starting Structured Streaming Query...")
    
    query = windowed_df.writeStream \
        .outputMode("append") \
        .foreachBatch(process_batch) \
        .trigger(processingTime="1 minute") # Process the latest data every minute
        .option("checkpointLocation", CHECKPOINT_LOCATION) \
        .start()

    try:
        query.awaitTermination(timeout=7200) # Time out of 2 hours 
    except:
        print("Streaming query terminated.")
    finally:
        if query.isActive:
            query.stop()
        spark.stop()

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: streaming_consumer.py <kafka_vm_internal_ip:9092>")
        sys.exit(-1)

    KAFKA_BROKERS = sys.argv[1]
    run_streaming_job(KAFKA_BROKERS)